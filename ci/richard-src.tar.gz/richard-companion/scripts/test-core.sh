#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
TMP=$(mktemp -d)
trap 'rm -rf "$TMP"' EXIT
javac -d "$TMP" app/src/main/java/com/chaos/richard/core/Command.java app/src/main/java/com/chaos/richard/core/CommandParser.java app/src/main/java/com/chaos/richard/core/Policy.java scripts/PolicySelfTest.java
java -cp "$TMP" PolicySelfTest
python3 -m unittest discover -s termux -p 'test_*.py'
