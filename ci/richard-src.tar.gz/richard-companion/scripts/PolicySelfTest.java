import com.chaos.richard.core.*;

/** Pure JDK smoke check when Android SDK/Gradle are not installed. */
class PolicySelfTest {
    private static int cases;
    static void check(boolean expected, String description) {
        cases++; if (!expected) throw new AssertionError(description);
    }
    public static void main(String[] args) {
        check(CommandParser.parse("Richard read screen").action==Command.Action.READ,"read");
        check(CommandParser.parse("hey Richard open work orders").action==Command.Action.OPEN_WORK_ORDERS,"navigate");
        check(CommandParser.parse("select order ABC-123").action==Command.Action.SELECT_ORDER,"select");
        check(CommandParser.parse("accept this job").action==Command.Action.ACCEPT_ORDER,"accept");
        check(CommandParser.parse("add note replaced outlet").action==Command.Action.ADD_NOTE,"note");
        check(CommandParser.parse("save note").action==Command.Action.SAVE_NOTE,"save");
        check(CommandParser.parse("start work").action==Command.Action.START_ORDER,"start");
        check(CommandParser.parse("open completion").action==Command.Action.OPEN_COMPLETION,"completion modal");
        check(CommandParser.parse("open camera").action==Command.Action.OPEN_CAMERA,"camera handoff");
        check(CommandParser.parse("submit completion with evidence").action==Command.Action.SUBMIT_COMPLETION,"explicit completion");
        check(CommandParser.parse("stop").action==Command.Action.STOP,"stop");
        check(CommandParser.parse("remember that filters are in truck").action==Command.Action.REMEMBER,"remember");
        check(CommandParser.parse("recall filters").action==Command.Action.RECALL,"recall");
        check(Policy.canAccessPackage("com.digitaldivide.chaoscoordinated"),"target package");
        check(!Policy.canAccessPackage("com.android.settings"),"other apps");
        check(Policy.isRestricted("Management"),"admin guard");
        check(Policy.isSensitive("Enter password"),"password guard");
        check(Policy.isSensitive("OTP"),"otp guard");
        check(!Policy.validNote("the password is 1234"),"credential note guard");
        check(!Policy.validOrderTarget("payroll"),"restricted target");
        check(Policy.validOrderTarget("job 132"),"job target");
        System.out.println("PASS " + cases + " core policy checks");
    }
}
