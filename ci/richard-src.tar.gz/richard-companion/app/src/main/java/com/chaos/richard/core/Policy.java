package com.chaos.richard.core;

import java.util.Locale;
import java.util.regex.Pattern;

/** Deliberately non-configurable scope. A model cannot widen these rules. */
public final class Policy {
    private Policy() {}
    public static final String TARGET_PACKAGE = "com.digitaldivide.chaoscoordinated";
    public static final int MAX_ACTIONS_PER_REQUEST = 6;
    private static final Pattern SENSITIVE = Pattern.compile(
        "(?i)(password|passcode|\\bpin\\b(?:\\s+code)?|one.time|otp|verification\\s+code|" +
        "security\\s+answer|secret|api[ _-]?key|bearer\\s+|ssn|social\\s+security|" +
        "credit\\s+card|\\b(?:\\d[ -]*?){13,19}\\b)"
    );
    private static final Pattern RESTRICTED = Pattern.compile(
        "(?i)(admin(?:istrat(?:or|ion|ive))?|management|payroll|billing|" +
        "user\\s+roles?|permissions?|employee\\s+records?|supervisor\\s+only|" +
        "database|security\\s+settings|delete\\s+account|privileged)"
    );
    public static boolean canAccessPackage(String pkg) {
        return TARGET_PACKAGE.equals(pkg);
    }
    public static boolean isSensitive(String text) {
        return text != null && SENSITIVE.matcher(text).find();
    }
    public static boolean isRestricted(String label) {
        return label != null && RESTRICTED.matcher(label).find();
    }
    public static String safeLabel(String text) {
        if (text == null || text.isEmpty()) return "";
        if (isSensitive(text)) return "[redacted]";
        return text.replaceAll("[\\p{Cntrl}&&[^\\n]]", " ").trim();
    }
    public static String normalize(String s) {
        return s == null ? "" : s.toLowerCase(Locale.ROOT).replaceAll("[^\\p{L}\\p{N}]+", " ").trim();
    }
    public static boolean validOrderTarget(String value) {
        return value != null && value.trim().length() >= 3 && value.length() <= 80 &&
            !isSensitive(value) && !isRestricted(value);
    }
    public static boolean validNote(String text) {
        return text != null && text.trim().length() >= 3 && text.length() <= 500 &&
            !isSensitive(text) && !isRestricted(text);
    }
    public static boolean screenTargetMatches(String visible, String requested) {
        String v = normalize(visible), r = normalize(requested);
        return validOrderTarget(requested) && !isRestricted(visible) && !isSensitive(visible) &&
            (v.equals(r) || v.contains(r));
    }
}
