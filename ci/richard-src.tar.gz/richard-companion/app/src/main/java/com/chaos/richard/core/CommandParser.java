package com.chaos.richard.core;

import java.util.Locale;
import static com.chaos.richard.core.Command.Action;

/** Offline first. No special privileges or arbitrary tap/type/system commands. */
public final class CommandParser {
    private CommandParser() {}
    public static Command parse(String input) {
        if (input == null || input.trim().isEmpty()) return new Command(Action.HELP, "");
        String original = input.trim();
        String s = original.toLowerCase(Locale.ROOT).replaceFirst("^(hey\\s+)?richard[, :]*", "").trim();
        if (s.matches("(stop|cancel|abort|halt)(\\s+.*)?")) return new Command(Action.STOP, "");
        if (s.matches("(help|commands|what can you do)\\??")) return new Command(Action.HELP, "");
        if (s.startsWith("remember that ")) return new Command(Action.REMEMBER, s.substring(14));
        if (s.startsWith("recall ")) return new Command(Action.RECALL, s.substring(7));
        if (s.matches("(clear|delete|forget) (my )?(notes|memory)")) return new Command(Action.CLEAR_MEMORY, "");
        if (s.matches("(read|describe|tell me|what.s on)( the)?( current)? screen.*|read (my )?menu")) return new Command(Action.READ, "");
        if (s.matches("(open|show|go to|navigate to)( my| the)? (work orders|assigned jobs|jobs)")) return new Command(Action.OPEN_WORK_ORDERS, "");
        if (s.startsWith("select order ") || s.startsWith("open order ") || s.startsWith("choose order ")) {
            String target = s.replaceFirst("^(select|open|choose) order\\s+", "");
            return Policy.validOrderTarget(target) ? new Command(Action.SELECT_ORDER, target) : new Command(Action.UNKNOWN, "");
        }
        if (s.matches("(accept|take|claim)( this| the| my)?( selected)?( work)?( order| job)?")) return new Command(Action.ACCEPT_ORDER, "");
        if (s.startsWith("add note ") || s.startsWith("enter note ")) {
            String note = s.replaceFirst("^(add|enter) note\\s+", "");
            return Policy.validNote(note) ? new Command(Action.ADD_NOTE, note) : new Command(Action.UNKNOWN, "");
        }
        if (s.matches("(save|submit)( my| the)? (note|work note)")) return new Command(Action.SAVE_NOTE, "");
        if (s.matches("(start|begin)( this| the)?( selected)?( work| job| order)?")) return new Command(Action.START_ORDER, "");
        if (s.matches("(open|show)( the)? completion( form| evidence)?|prepare completion|finish work")) return new Command(Action.OPEN_COMPLETION, "");
        if (s.matches("(take|add|open)( a| the)?( completion)? photo|open camera|take completion photo")) return new Command(Action.OPEN_CAMERA, "");
        if (s.equals("submit completion with evidence")) return new Command(Action.SUBMIT_COMPLETION, "");
        if (s.matches("(scroll|move) down")) return new Command(Action.SCROLL_DOWN, "");
        if (s.matches("(scroll|move) up")) return new Command(Action.SCROLL_UP, "");
        return new Command(Action.UNKNOWN, "");
    }
    public static String help() {
        return "I can read the Chaos screen, open work orders, select order <name or ID>, " +
            "accept the selected job, start work, open completion, open camera, add note <approved text>, " +
            "submit completion with evidence (only after a manual photo), scroll up or down, " +
            "remember that <fact>, recall <topic>, clear memory, and STOP. " +
            "You sign in yourself. I never type passwords or access management screens.";
    }
}
