package com.chaos.richard.core;

public final class Command {
    public enum Action {
        HELP, READ, OPEN_WORK_ORDERS, SELECT_ORDER, ACCEPT_ORDER, ADD_NOTE,
        SAVE_NOTE, START_ORDER, OPEN_COMPLETION, OPEN_CAMERA, SUBMIT_COMPLETION, SCROLL_DOWN, SCROLL_UP, REMEMBER, RECALL, CLEAR_MEMORY, STOP,
        UNKNOWN
    }
    public final Action action;
    public final String argument;
    public Command(Action action, String argument) {
        this.action = action;
        this.argument = argument == null ? "" : argument.trim();
    }
}
