package com.chaos.richard;

import android.accessibilityservice.AccessibilityService;
import android.content.*;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.os.*;
import android.speech.tts.TextToSpeech;
import android.view.*;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.*;
import com.chaos.richard.core.Command;
import com.chaos.richard.core.CommandParser;
import com.chaos.richard.core.Policy;
import java.util.*;
import java.util.concurrent.atomic.AtomicBoolean;

/** Native accessibility, not coordinate automation. Every action is UI-grounded. */
public final class RichardService extends AccessibilityService {
    public static volatile RichardService instance;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final AtomicBoolean busy = new AtomicBoolean(false);
    private WindowManager wm;
    private View bubble;
    private TextToSpeech speaker;
    private volatile boolean cancelled;
    private int actionCount = 0;
    private int unchangedCount = 0;
    private String lastSnapshot = "";
    private boolean noteEntered = false;
    private String editedNoteText = "";
    private String selectedOrder = "";
    private boolean completionModalOpen = false;

    @Override protected void onServiceConnected() {
        super.onServiceConnected(); instance = this;
        cancelled = false;
        wm = (WindowManager)getSystemService(WINDOW_SERVICE);
        speaker = new TextToSpeech(this, status -> { /* voice engine may be absent */ });
        showBubble();
        report("Richard is enabled. Sign in to Chaos yourself; I can read technician screens.");
    }
    @Override public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event == null || event.getPackageName() == null ||
            !Policy.canAccessPackage(event.getPackageName().toString())) return;
        if (busy.get()) return;
        android.content.SharedPreferences prefs = getSharedPreferences("bridge",MODE_PRIVATE);
        String pending = prefs.getString("pending", "");
        if (pending.isEmpty() || prefs.getBoolean("cancelled",false)) return;
        prefs.edit().remove("pending").apply();
        busy.set(true); cancelled=false; actionCount=0;
        // Let Chaos finish rendering after launch before inspecting its live accessibility nodes.
        main.postDelayed(() -> startRequest(pending), 400);
    }
    private void startRequest(String raw) {
        if (cancelled) { busy.set(false); return; }
        Command c = CommandParser.parse(raw);
        if (c.action != Command.Action.UNKNOWN) { perform(c); return; }
        boolean optIn = getSharedPreferences("MainActivity",MODE_PRIVATE).getBoolean("planner", false);
        if (!optIn) { reportDone("Unknown offline instruction. Open Richard for help."); return; }
        String token = getSharedPreferences("MainActivity",MODE_PRIVATE).getString("planner_token", "");
        if (token.length()<12) { reportDone("Set a local planner pairing token in Richard first."); return; }
        Screen screen = inspect();
        if (screen == null) { reportDone("Not on a readable Chaos technician screen."); return; }
        final String snapshot = screen.safeSummary;
        new Thread(() -> {
            final Command planned = PlannerClient.plan(raw,snapshot,token);
            main.post(() -> {
                if (cancelled) { busy.set(false); return; }
                if (planned == null) { reportDone("Local planner is unavailable or returned an unsafe action."); return; }
                // The planner cannot initiate acceptance or user text entry unless explicitly requested.
                String lower = raw.toLowerCase(Locale.ROOT);
                if (planned.action == Command.Action.ACCEPT_ORDER &&
                    !(lower.contains("accept") || lower.contains("claim") || lower.contains("take"))) {
                    reportDone("Acceptance requires an explicit instruction."); return;
                }
                if (planned.action == Command.Action.ADD_NOTE && !lower.contains("note")) {
                    reportDone("Editing notes requires an explicit instruction."); return;
                }
                perform(planned);
            });
        },"Richard-planner").start();
    }
    private void perform(Command c) {
        if (cancelled || getSharedPreferences("bridge",MODE_PRIVATE).getBoolean("cancelled",false)) {
            reportDone("Stopped."); return;
        }
        if (unchangedCount >= 2 && c.action != Command.Action.READ && lastSnapshot.equals(inspect()==null?"":inspect().safeSummary)) { reportDone("Two unchanged screens detected. Make a manual change to Chaos before retrying."); return; }
        if (++actionCount > Policy.MAX_ACTIONS_PER_REQUEST) { reportDone("Six-action safety limit reached."); return; }
        Screen screen = inspect();
        if (screen == null) { reportDone("Stopped: current app isn't Chaos or its screen isn't readable."); return; }
        switch(c.action) {
            case READ: reportDone(screen.safeSummary.isEmpty() ? "No readable labels are exposed on this screen." : "Visible: " + screen.safeSummary); return;
            case OPEN_WORK_ORDERS:
                clickNamed(screen, new String[]{"work orders","my work orders","assigned jobs","my jobs"},"Work Orders", false); return;
            case SELECT_ORDER:
                selectedOrder=""; noteEntered=false; editedNoteText=""; completionModalOpen=false;
                if (!Policy.validOrderTarget(c.argument)) { reportDone("Invalid job name or ID."); return; }
                clickNamed(screen,new String[]{c.argument},"order " + c.argument,true); return;
            case ACCEPT_ORDER:
                if (selectedOrder.isEmpty() || !Policy.normalize(screen.safeSummary).contains(Policy.normalize(selectedOrder))) {
                    reportDone("First select a specific visible work order and confirm its detail screen before accepting it."); return;
                }
                clickNamed(screen,new String[]{"accept","accept job","accept order","accept work order"},"Accept",false); return;
            case START_ORDER:
                if (!onSelectedOrder(screen)) { reportDone("First select and verify the specific work order."); return; }
                clickNamed(screen,new String[]{"start"},"Start work",false); return;
            case OPEN_COMPLETION:
                if (!onSelectedOrder(screen)) { reportDone("First select and verify the specific work order."); return; }
                completionModalOpen=false; noteEntered=false; editedNoteText="";
                clickNamed(screen,new String[]{"complete work"},"Open completion",false); return;
            case OPEN_CAMERA:
                if (!completionModalOpen || !isCompletionModal(screen)) {
                    reportDone("Open the completion form before requesting the camera."); return;
                }
                clickNamed(screen,new String[]{"open camera take photo", "open camera & take photo"},"Open camera",false); return;
            case ADD_NOTE:
                if (!completionModalOpen || !isCompletionModal(screen)) {
                    reportDone("Open the actual Completion Evidence form before entering its note."); return;
                }
                fillNote(screen,c.argument); return;
            case SAVE_NOTE:
                reportDone("This Chaos version saves completion notes when work is completed, not through a separate Save Note button. Attach evidence, then say submit completion with evidence."); return;
            case SUBMIT_COMPLETION:
                if (!completionModalOpen || !isCompletionModal(screen)) { reportDone("Verified completion dialog is not open."); return; }
                if (!noteEntered || !hasNoteEditor(screen)) { reportDone("Provide a valid completion note first."); return; }
                if (Policy.normalize(screen.safeSummary).contains("no completion photos attached yet")) {
                    reportDone("I see no attached completion photo. Take a photo manually before submitting."); return;
                }
                if (screen.safeSummary.length() < 80) { reportDone("Not enough UI evidence to safely submit completion."); return; }
                clickNamed(screen,new String[]{"complete work"},"Submit completion",false); return;
            case SCROLL_DOWN: scroll(screen,AccessibilityNodeInfo.ACTION_SCROLL_FORWARD,"down"); return;
            case SCROLL_UP: scroll(screen,AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD,"up"); return;
            case STOP: stopWork(); return;
            default: reportDone("Only technician screen commands are allowed.");
        }
    }
    private void clickNamed(Screen screen,String[] allowedNames,String verb,boolean allowContains) {
        AccessibilityNodeInfo target = null;
        int uniqueMatches = 0;
        for (String desired : allowedNames) {
            for (AccessibilityNodeInfo node : screen.nodes) {
                String label = nodeLabel(node);
                if (label.isEmpty() || Policy.isRestricted(label) || Policy.isSensitive(label)) continue;
                boolean ok = allowContains ? Policy.screenTargetMatches(label,desired) :
                    Policy.normalize(label).equals(Policy.normalize(desired));
                if (ok) {
                    AccessibilityNodeInfo candidate = clickableParent(node);
                    if (candidate != null && (target == null || !target.equals(candidate))) {
                        uniqueMatches++;
                        if (target == null) target = candidate;
                    }
                }
            }
            if (target != null) break;
        }
        if (!allowContains && uniqueMatches > 1 && verb.equals("Accept")) {
            reportDone("More than one Accept control is visible; refusing an ambiguous tap."); return;
        }
        if (target == null) { reportDone("Can't find a clickable " + verb + " control on this Chaos screen."); return; }
        if (!stillChaos()) { reportDone("App changed. Refusing tap outside Chaos."); return; }
        String before = screen.safeSummary;
        boolean clicked = target.performAction(AccessibilityNodeInfo.ACTION_CLICK);
        if (!clicked) { reportDone("Android did not accept the " + verb + " tap."); return; }
        verifyAfter(verb,before);
    }
    private void fillNote(Screen screen,String note) {
        if (!Policy.validNote(note)) { reportDone("Note rejected: use 3–500 non-sensitive characters."); return; }
        if (!completionModalOpen || !isCompletionModal(screen)) {
            reportDone("Can't confirm the Completion Evidence form; no text entered."); return;
        }
        ArrayList<AccessibilityNodeInfo> editors = new ArrayList<>();
        for (AccessibilityNodeInfo node : screen.nodes) {
            if (!node.isEditable() || node.isPassword() || !node.isEnabled()) continue;
            String label=nodeLabel(node);
            if (Policy.isSensitive(label) || Policy.isRestricted(label)) continue;
            editors.add(node);
        }
        if (editors.size() != 1) {
            reportDone("Found " + editors.size() + " editable fields in the completion form. Refusing an ambiguous edit."); return;
        }
        if (!stillChaos()) { reportDone("App changed. Refusing input outside Chaos."); return; }
        Bundle args=new Bundle();
        args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE,note);
        if (!editors.get(0).performAction(AccessibilityNodeInfo.ACTION_SET_TEXT,args)) {
            reportDone("Completion note field doesn't support Android text entry."); return;
        }
        noteEntered=true; editedNoteText=note;
        verifyAfter("Enter completion note",screen.safeSummary);
    }
    private boolean onSelectedOrder(Screen screen) {
        return !selectedOrder.isEmpty() && Policy.normalize(screen.safeSummary).contains(Policy.normalize(selectedOrder));
    }
    private boolean isCompletionModal(Screen screen) {
        String labels=Policy.normalize(screen.safeSummary);
        return labels.contains("completion evidence") && labels.contains("complete finished work") && labels.contains("completion note");
    }
    private boolean hasNoteEditor(Screen screen) {
        for (AccessibilityNodeInfo node : screen.nodes) {
            String n=Policy.normalize(nodeLabel(node));
            if (node.isEditable() && !node.isPassword() && !Policy.isRestricted(n) &&
                (n.contains("note") || n.contains("comment") || n.contains("work performed") || n.contains("describe what was completed") ||
                 (!editedNoteText.isEmpty() && n.equals(Policy.normalize(editedNoteText))))) return true;
        }
        return false;
    }
    private void scroll(Screen screen,int direction,String label) {
        for (AccessibilityNodeInfo node : screen.nodes) {
            if (node.isScrollable() && node.isEnabled()) {
                if (!stillChaos()) { reportDone("App changed. Scroll blocked."); return; }
                if (node.performAction(direction)) { verifyAfter("Scroll "+label,screen.safeSummary); return; }
            }
        }
        reportDone("No accessible scroll container found here.");
    }
    private void verifyAfter(String verb,String before) {
        lastSnapshot = before;
        main.postDelayed(() -> {
            if (cancelled) { busy.set(false); return; }
            Screen updated = inspect();
            if (updated == null) { reportDone(verb + " tapped, but the Chaos screen is no longer active. Outcome unverified."); return; }
            String after = updated.safeSummary;
            if (after.equals(before)) {
                unchangedCount++;
                reportDone(verb + " action sent, but the accessible screen didn't change. Outcome not confirmed."); return;
            }
            unchangedCount=0;
            if (verb.equals("Open completion")) {
                completionModalOpen=isCompletionModal(updated);
                if (completionModalOpen) reportDone("Completion form is open. Add a note and attach a real photo manually before submitting.");
                else reportDone("Tapped Complete work, but I couldn't verify that its form opened.");
            } else if (verb.equals("Submit completion")) {
                completionModalOpen=false; noteEntered=false; editedNoteText="";
                String normalized=Policy.normalize(after);
                if (normalized.contains("work completed") || normalized.contains("status completed") ||
                    normalized.contains("assignment status completed"))
                    reportDone("Chaos now displays a completed status. Management must confirm saved evidence.");
                else reportDone("Completion was requested but not confirmed by the visible status. Check Chaos directly.");
            } else if (verb.startsWith("order ")) {
                String name=verb.substring(6);
                if (Policy.normalize(after).contains(Policy.normalize(name))) {
                    selectedOrder=name;
                    reportDone("Order detail changed and still shows " + name + ". Ready for an explicit Accept instruction.");
                } else reportDone("Selected order tapped, but I can't confirm the correct order is open.");
            } else if (verb.equals("Accept")) {
                String normalized = Policy.normalize(after);
                if (normalized.contains("accepted") || normalized.contains("in progress"))
                    reportDone("Accept tapped. The Chaos screen now displays accepted / in-progress status.");
                else reportDone("Accept tapped. Screen changed but acceptance status isn't confirmed. Check the job.");
            } else reportDone(verb + " action sent. Updated Chaos screen: " + after);
        },800);
    }
    private static String nodeLabel(AccessibilityNodeInfo node) {
        if (node.isPassword()) return "";
        CharSequence t = node.getText(), d = node.getContentDescription(), h = node.getHintText();
        String label = t != null && t.length()>0 ? t.toString() : (d != null && d.length()>0 ? d.toString() : (h!=null ? h.toString() : ""));
        return Policy.safeLabel(label);
    }
    private AccessibilityNodeInfo clickableParent(AccessibilityNodeInfo node) {
        AccessibilityNodeInfo current = node;
        for (int depth=0; depth<5 && current!=null;depth++) {
            if (current.isClickable() && current.isEnabled() &&
                !current.isPassword() && !Policy.isRestricted(nodeLabel(current))) return current;
            current=current.getParent();
        }
        return null;
    }
    private Screen inspect() {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root==null || root.getPackageName()==null || !Policy.canAccessPackage(root.getPackageName().toString())) return null;
        ArrayList<AccessibilityNodeInfo> nodes = new ArrayList<>();
        StringBuilder labels = new StringBuilder();
        ArrayDeque<AccessibilityNodeInfo> queue = new ArrayDeque<>(); queue.add(root);
        while (!queue.isEmpty() && nodes.size()<180) {
            AccessibilityNodeInfo node=queue.removeFirst();
            if (node == null) continue;
            nodes.add(node);
            String label=nodeLabel(node);
            if (!label.isEmpty() && !Policy.isRestricted(label) && !label.equals("[redacted]") && labels.length()<1300) {
                labels.append(label,0,Math.min(90,label.length())).append(" | ");
            }
            for (int i=0;i<node.getChildCount() && queue.size()<200;i++) {
                AccessibilityNodeInfo child=node.getChild(i); if (child!=null) queue.add(child);
            }
        }
        return new Screen(nodes,labels.toString());
    }
    private boolean stillChaos() {
        AccessibilityNodeInfo root=getRootInActiveWindow();
        return root!=null && root.getPackageName()!=null && Policy.canAccessPackage(root.getPackageName().toString());
    }
    private static final class Screen {
        final ArrayList<AccessibilityNodeInfo> nodes;
        final String safeSummary;
        Screen(ArrayList<AccessibilityNodeInfo> nodes,String safeSummary) {
            this.nodes=nodes; this.safeSummary=safeSummary;
        }
    }
    private void report(String message) {
        getSharedPreferences("bridge",MODE_PRIVATE).edit().putString("status",message).apply();
    }
    private void reportDone(String message) {
        report(message); busy.set(false);
        // Speech is optional; never speak credential-like text.
        if (speaker != null && !Policy.isSensitive(message))
            speaker.speak(message.length()>260?message.substring(0,260):message,TextToSpeech.QUEUE_FLUSH,null,"richard_status");
    }
    public void stopWork() {
        cancelled=true;
        getSharedPreferences("bridge",MODE_PRIVATE).edit().putBoolean("cancelled",true).remove("pending").apply();
        main.removeCallbacksAndMessages(null);
        busy.set(false); selectedOrder=""; completionModalOpen=false; noteEntered=false; editedNoteText=""; report("Richard stopped.");
        if (speaker!=null) speaker.stop();
    }
    private void showBubble() {
        if (wm==null || bubble!=null) return;
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL); row.setPadding(6,6,6,6);
        row.setBackgroundColor(Color.rgb(14,23,36));
        Button open=new Button(this); open.setText("R • TALK"); open.setContentDescription("Open Richard voice controls");
        Button stop=new Button(this); stop.setText("STOP"); stop.setContentDescription("Stop Richard actions");
        open.setOnClickListener(v -> {
            Intent i=new Intent(this,MainActivity.class);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            i.putExtra("auto_listen",true);
            startActivity(i);
        });
        stop.setOnClickListener(v -> stopWork());
        row.addView(open); row.addView(stop);
        WindowManager.LayoutParams p=new WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT);
        p.gravity=Gravity.TOP|Gravity.END; p.y=110;
        try { wm.addView(row,p); bubble=row; } catch (Exception e) { report("Overlay unavailable; use Richard launcher instead."); }
    }
    @Override public void onInterrupt() { stopWork(); }
    @Override public void onDestroy() {
        stopWork(); if (wm!=null && bubble!=null) { try { wm.removeView(bubble); }catch(Exception ignored){} }
        if (speaker!=null) speaker.shutdown();
        if (instance==this) instance=null;
        super.onDestroy();
    }
}
