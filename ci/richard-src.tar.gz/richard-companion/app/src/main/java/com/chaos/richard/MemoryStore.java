package com.chaos.richard;

import android.content.Context;
import com.chaos.richard.core.Policy;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.Locale;

/** On-device notes, not included in APK or copied to cloud. */
public final class MemoryStore {
    private final Context context;
    public MemoryStore(Context context) { this.context = context.getApplicationContext(); }
    private File file() { return new File(context.getFilesDir(), "richard-notes.md"); }
    public String remember(String note) {
        if (!Policy.validNote(note)) return "I can't save that note. Avoid credentials, sensitive data, and management information.";
        try {
            File f = file();
            if (f.exists() && f.length() > 16_384) return "My notes are full. Delete them before saving more.";
            try (FileOutputStream out = new FileOutputStream(f, true)) {
                out.write(("- " + note.replace('\n',' ') + "\n").getBytes(StandardCharsets.UTF_8));
            }
            return "Saved locally on this phone.";
        } catch (IOException e) { return "Couldn't save the note."; }
    }
    public String recall(String topic) {
        if (topic == null || topic.trim().isEmpty() || Policy.isSensitive(topic)) return "Tell me a safe topic to search.";
        File f = file();
        if (!f.exists()) return "No notes saved yet.";
        String target = topic.toLowerCase(Locale.ROOT).trim();
        StringBuilder matches = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(f), StandardCharsets.UTF_8))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.toLowerCase(Locale.ROOT).contains(target) && matches.length() < 800) matches.append(line).append('\n');
            }
        } catch (IOException e) { return "Couldn't read the notes."; }
        return matches.length() == 0 ? "No matching notes for " + topic : matches.toString().trim();
    }
    public String clear() { return !file().exists() || file().delete() ? "Local notes deleted." : "Couldn't delete the notes."; }
}
