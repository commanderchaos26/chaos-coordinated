package com.chaos.richard;

import android.content.Context;
import com.chaos.richard.core.Policy;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.Locale;

/** Tiny keyword retrieval index over bundled, read-only Markdown. */
public final class KnowledgeBase {
    private static final String[] NOTES={"01-onboarding.md","02-maintenance.md","03-work-orders.md","04-demo.md"};
    private KnowledgeBase() {}
    public static String lookup(Context ctx,String topic) {
        if (topic==null || topic.length()<3 || Policy.isSensitive(topic)) return "No matching reference.";
        String search=topic.toLowerCase(Locale.ROOT);
        StringBuilder output=new StringBuilder();
        for (String name:NOTES) {
            try (BufferedReader reader=new BufferedReader(new InputStreamReader(ctx.getAssets().open("knowledge/"+name),StandardCharsets.UTF_8))) {
                String line;
                while ((line=reader.readLine())!=null && output.length()<1000) {
                    if (line.toLowerCase(Locale.ROOT).contains(search))
                        output.append(name.replace(".md","")).append(": ").append(line).append('\n');
                }
            } catch(IOException ignored) {}
        }
        return output.length()>0 ? output.toString().trim() : "No matching reference.";
    }
}
