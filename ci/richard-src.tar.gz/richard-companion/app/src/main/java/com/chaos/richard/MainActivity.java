package com.chaos.richard;

import android.Manifest;
import android.app.Activity;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.*;
import android.provider.Settings;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.view.*;
import android.widget.*;
import com.chaos.richard.core.Command;
import com.chaos.richard.core.CommandParser;
import com.chaos.richard.core.Policy;
import java.util.ArrayList;

public class MainActivity extends Activity {
    private final int bg = Color.rgb(14,23,36), card = Color.rgb(26,40,58);
    private final int cyan = Color.rgb(30,204,185), light = Color.rgb(232,241,248);
    private TextView status;
    private EditText input, token;
    private Switch llmSwitch;
    private SpeechRecognizer speech;
    private boolean listening = false;

    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved); draw();
        if (getIntent().getBooleanExtra("auto_listen", false))
            new Handler(Looper.getMainLooper()).postDelayed(this::listen,250);
    }
    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent); setIntent(intent);
        if (intent.getBooleanExtra("auto_listen", false))
            new Handler(Looper.getMainLooper()).postDelayed(this::listen,250);
    }
    @Override public void onRequestPermissionsResult(int requestCode,String[] permissions,int[] grantResults) {
        super.onRequestPermissionsResult(requestCode,permissions,grantResults);
        if (requestCode==100 && grantResults.length>0 && grantResults[0]==PackageManager.PERMISSION_GRANTED)
            new Handler(Looper.getMainLooper()).postDelayed(this::listen,200);
        else if (requestCode==100) update("Microphone permission denied. Typed commands are still available.");
    }
    private int dp(int v) { return Math.round(getResources().getDisplayMetrics().density*v); }
    private TextView text(String value, int size) {
        TextView t = new TextView(this); t.setText(value); t.setTextSize(size); t.setTextColor(light);
        t.setPadding(0,dp(8),0,dp(8)); return t;
    }
    private Button button(String value, Runnable action) {
        Button b = new Button(this); b.setAllCaps(false); b.setText(value); b.setTextColor(bg);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(cyan));
        b.setOnClickListener(v -> action.run()); return b;
    }
    private void draw() {
        ScrollView scroll = new ScrollView(this); scroll.setFillViewport(true); scroll.setBackgroundColor(bg);
        LinearLayout layout = new LinearLayout(this); layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(dp(22),dp(28),dp(22),dp(26)); scroll.addView(layout);
        TextView heading = text("RICHARD", 32); heading.setTypeface(Typeface.DEFAULT,Typeface.BOLD); heading.setTextColor(cyan);
        layout.addView(heading);
        layout.addView(text("CHAOS COORDINATED • TECHNICIAN COMPANION", 13));
        layout.addView(text("Tap Speak or enter one instruction. Only the official Chaos Coordinated app may be controlled.", 14));
        status = text("Ready. Enable Richard in Android Accessibility, then sign into Chaos manually.",15);
        status.setBackgroundColor(card); status.setPadding(dp(14),dp(14),dp(14),dp(14));
        layout.addView(status);
        input = new EditText(this); input.setTextColor(light); input.setHintTextColor(Color.LTGRAY);
        input.setSingleLine(false); input.setMinLines(2); input.setHint("E.g. Richard open work orders");
        input.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        layout.addView(input);
        layout.addView(button("Run instruction in Chaos", () -> submit(input.getText().toString())));
        layout.addView(button("Speak • push to talk", this::listen));
        layout.addView(button("STOP all Richard actions", this::stop));
        layout.addView(button("Enable / disable Accessibility service", () -> {
            startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
        }));
        layout.addView(button("Open Chaos Coordinated", this::launchChaos));
        llmSwitch = new Switch(this); llmSwitch.setText("Use local Termux planner (opt-in)");
        llmSwitch.setTextColor(light); llmSwitch.setChecked(getPreferences(MODE_PRIVATE).getBoolean("planner", false));
        llmSwitch.setOnCheckedChangeListener((v,on) -> getPreferences(MODE_PRIVATE).edit().putBoolean("planner",on).apply());
        layout.addView(llmSwitch);
        token = new EditText(this); token.setTextColor(light); token.setHintTextColor(Color.LTGRAY);
        token.setHint("Local planner pairing token (not an AI API key)");
        token.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD);
        token.setText(getPreferences(MODE_PRIVATE).getString("planner_token", ""));
        layout.addView(token);
        layout.addView(button("Save local planner pairing", () -> {
            getPreferences(MODE_PRIVATE).edit().putString("planner_token", token.getText().toString().trim()).apply();
            update("Saved local pairing. Never paste an AI provider API key here.");
        }));
        layout.addView(text("Examples: read screen • select order ABC-123 • accept this job • start work • open completion • open camera • add note replaced outlet • submit completion with evidence",13));
        layout.addView(text("Accessibility permission is powerful. This demo service is package-restricted, can be revoked in Settings, and never performs systemwide gestures.",12));
        setContentView(scroll);
    }
    @Override public void onResume() { super.onResume();
        String latest = getSharedPreferences("bridge",MODE_PRIVATE).getString("status", "");
        if (!latest.isEmpty()) update(latest);
    }
    private void update(String s) { if (status != null) status.setText(s); }
    private void submit(String raw) {
        Command cmd = CommandParser.parse(raw);
        if (cmd.action == Command.Action.STOP) { stop(); return; }
        if (cmd.action == Command.Action.HELP) { update(CommandParser.help()); return; }
        MemoryStore memory = new MemoryStore(this);
        if (cmd.action == Command.Action.REMEMBER) { update(memory.remember(cmd.argument)); return; }
        if (cmd.action == Command.Action.RECALL) { String notes = memory.recall(cmd.argument); String reference=KnowledgeBase.lookup(this,cmd.argument); update(notes + "\n\nReference: " + reference); return; }
        if (cmd.action == Command.Action.CLEAR_MEMORY) { update(memory.clear()); return; }
        if (cmd.action == Command.Action.UNKNOWN && !llmSwitch.isChecked()) {
            update("I don't know that offline instruction. " + CommandParser.help()); return;
        }
        if (Policy.isSensitive(raw) || Policy.isRestricted(raw)) {
            update("I won't handle credentials or management-only operations."); return;
        }
        getSharedPreferences("bridge",MODE_PRIVATE).edit()
            .putBoolean("cancelled", false).putString("pending",raw).putString("status","Going to Chaos to inspect the screen…").apply();
        update("Going to Chaos to inspect the screen…");
        launchChaos();
    }
    private void stop() {
        getSharedPreferences("bridge",MODE_PRIVATE).edit().putBoolean("cancelled",true).remove("pending").putString("status","STOP requested").apply();
        if (speech != null) { try { speech.cancel(); } catch (Exception ignored) {} }
        if (RichardService.instance != null) RichardService.instance.stopWork();
        update("STOP requested. No more actions will run.");
    }
    private void launchChaos() {
        Intent intent = getPackageManager().getLaunchIntentForPackage(Policy.TARGET_PACKAGE);
        if (intent == null) { update("Chaos Coordinated isn't installed or its launch activity is unavailable."); return; }
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(intent);
    }
    private void listen() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},100); return;
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { update("No speech recognition service found. Use typed commands."); return; }
        if (listening) return;
        speech = SpeechRecognizer.createSpeechRecognizer(this);
        speech.setRecognitionListener(new RecognitionListener() {
            public void onReadyForSpeech(Bundle p) { listening=true; update("Listening… speak one instruction."); }
            public void onBeginningOfSpeech() {}
            public void onRmsChanged(float f) {}
            public void onBufferReceived(byte[] d) {}
            public void onEndOfSpeech() {}
            public void onError(int error) { listening=false; update("Speech recognition failed ("+error+"). Try again or type."); closeSpeech(); }
            public void onResults(Bundle data) { listening=false;
                ArrayList<String> results = data.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                closeSpeech(); if (results!=null && !results.isEmpty()) { input.setText(results.get(0)); submit(results.get(0)); }
                else update("No speech recognized.");
            }
            public void onPartialResults(Bundle b) {}
            public void onEvent(int type, Bundle b) {}
        });
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS,1);
        speech.startListening(intent);
    }
    private void closeSpeech() { if (speech != null) { speech.destroy(); speech=null; } }
    @Override protected void onDestroy() { closeSpeech(); super.onDestroy(); }
}
