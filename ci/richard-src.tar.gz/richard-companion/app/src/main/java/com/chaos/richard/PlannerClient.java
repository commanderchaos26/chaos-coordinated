package com.chaos.richard;

import com.chaos.richard.core.Command;
import com.chaos.richard.core.Policy;
import org.json.JSONObject;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

/** Opt-in single-step planner. Can call LOOPBACK ONLY. Android validates every response. */
final class PlannerClient {
    private PlannerClient() {}
    static Command plan(String prompt,String screen,String localToken) {
        HttpURLConnection connection=null;
        try {
            if (localToken==null || localToken.length()<12 || Policy.isSensitive(prompt) || Policy.isRestricted(prompt)) return null;
            URL url=new URL("http://127.0.0.1:8765/plan");
            connection=(HttpURLConnection)url.openConnection();
            connection.setConnectTimeout(1500);connection.setReadTimeout(12000);
            connection.setRequestMethod("POST"); connection.setDoOutput(true);
            connection.setRequestProperty("Content-Type","application/json");
            connection.setRequestProperty("X-Richard-Token",localToken);
            JSONObject data=new JSONObject();
            data.put("instruction",prompt.substring(0,Math.min(prompt.length(),500)));
            data.put("screen",screen.substring(0,Math.min(screen.length(),1300)));
            byte[] body=data.toString().getBytes(StandardCharsets.UTF_8);
            try (OutputStream out=connection.getOutputStream()) { out.write(body); }
            if (connection.getResponseCode()!=200) return null;
            ByteArrayOutputStream buffer=new ByteArrayOutputStream();
            try (InputStream in=connection.getInputStream()) {
                byte[] chunk=new byte[1024]; int len;
                while((len=in.read(chunk))!=-1 && buffer.size()<4096) buffer.write(chunk,0,len);
            }
            JSONObject response=new JSONObject(buffer.toString(StandardCharsets.UTF_8.name()));
            String action=response.optString("action","");
            String target=response.optString("target","");
            String text=response.optString("text","");
            switch(action) {
                case "read": return new Command(Command.Action.READ, "");
                case "open_work_orders": return new Command(Command.Action.OPEN_WORK_ORDERS, "");
                case "select_order": return Policy.validOrderTarget(target) ? new Command(Command.Action.SELECT_ORDER,target) : null;
                case "accept_order": return new Command(Command.Action.ACCEPT_ORDER, "");
                case "add_note": return Policy.validNote(text) ? new Command(Command.Action.ADD_NOTE,text) : null;
                case "save_note": return new Command(Command.Action.SAVE_NOTE, "");
                case "start_order": return new Command(Command.Action.START_ORDER, "");
                case "open_completion": return new Command(Command.Action.OPEN_COMPLETION, "");
                case "open_camera": return new Command(Command.Action.OPEN_CAMERA, "");
                // Completion is intentionally NOT delegated to the LLM: user must use the exact offline phrase.
                case "scroll_down": return new Command(Command.Action.SCROLL_DOWN, "");
                case "scroll_up": return new Command(Command.Action.SCROLL_UP, "");
                default: return null;
            }
        } catch (Exception e) { return null; }
        finally { if(connection!=null) connection.disconnect(); }
    }
}
