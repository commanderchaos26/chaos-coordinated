# Technician onboarding — demonstration reference

This is a sample knowledge note, not a verified employer policy.

1. A supervisor provisions a dedicated technician account in Chaos Coordinated.
2. The technician signs in manually and confirms their assigned role.
3. Check the visible assigned work orders before accepting a job.
4. Work only on jobs actually assigned and within authorization.
5. Tell a supervisor when a required field, evidence upload, or job control is unavailable.
