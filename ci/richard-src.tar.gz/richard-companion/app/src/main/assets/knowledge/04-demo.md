# Richard Android demonstration runbook

1. Enable Richard in Accessibility Settings; only Chaos Coordinated may be read or tapped.
2. Supervisor signs in to a dedicated technician test account in Chaos (never through Richard).
3. Say "Richard read screen" to inspect visible technician options.
4. Say "Richard open work orders".
5. Say "Richard select order <visible ID or title>".
6. Say "Richard accept this job" and confirm that the app changes to Accepted or In Progress.
7. Say "Richard start work" and verify that the assignment becomes active.
8. Say "Richard open completion" to show the Completion Evidence modal.
9. Say "Richard open camera" and manually take a real completion photo using Android's camera.
10. Say "Richard add note <approved maintenance note>" while the completion modal is visible.
11. Say "Richard submit completion with evidence" only after checking the photo and note.
12. Supervisor verifies saved completion, attached evidence and status in another authorized management session.
13. Say STOP or disable the Accessibility service immediately if anything unexpected occurs.
