# Maintenance work categories — reference

Common intake categories: plumbing, electrical, appliances, drywall and paint, cleaning.
Confirm urgency and location from the actual work order. Electrical work, gas, water emergencies,
fall risks and lockout/tagout require appropriate trained personnel and employer procedure.
This note does not authorize work beyond qualifications or employer instructions.
