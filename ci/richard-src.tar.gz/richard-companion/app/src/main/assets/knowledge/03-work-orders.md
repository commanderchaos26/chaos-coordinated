# Work orders — technician process

Locate Work Orders / Assigned Jobs in Chaos Coordinated. Read the visible list.
Select only a job explicitly identified by its on-screen label or ID. Accept only when
an actual Accept control is present. After any action, refresh the screen and confirm
that the status changed. If it did not, report the action as unverified.
After acceptance, Start the assignment. The current Chaos task-detail screen has a
Complete work control that opens the Completion Evidence dialog. Take a real photo,
enter approved completion text, and submit only after checking the evidence. There is
no stand-alone Save Note control in the inspected source. Completion must be checked
by an authorized management user separately.
