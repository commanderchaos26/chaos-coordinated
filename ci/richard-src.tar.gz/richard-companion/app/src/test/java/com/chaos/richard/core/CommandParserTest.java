package com.chaos.richard.core;

import org.junit.Test;
import static org.junit.Assert.*;
import static com.chaos.richard.core.Command.Action;

public class CommandParserTest {
    @Test public void offlineCommands() {
        assertEquals(Action.READ,CommandParser.parse("Richard read screen").action);
        assertEquals(Action.OPEN_WORK_ORDERS,CommandParser.parse("hey Richard open work orders").action);
        assertEquals(Action.SELECT_ORDER,CommandParser.parse("select order ABC-123").action);
        assertEquals("abc-123",CommandParser.parse("select order ABC-123").argument);
        assertEquals(Action.ACCEPT_ORDER,CommandParser.parse("accept this job").action);
        assertEquals(Action.ADD_NOTE,CommandParser.parse("add note replaced outlet").action);
        assertEquals(Action.SAVE_NOTE,CommandParser.parse("save note").action);
        assertEquals(Action.START_ORDER,CommandParser.parse("start work").action);
        assertEquals(Action.OPEN_COMPLETION,CommandParser.parse("open completion").action);
        assertEquals(Action.OPEN_CAMERA,CommandParser.parse("open camera").action);
        assertEquals(Action.SUBMIT_COMPLETION,CommandParser.parse("submit completion with evidence").action);
        assertEquals(Action.SCROLL_DOWN,CommandParser.parse("scroll down").action);
        assertEquals(Action.STOP,CommandParser.parse("stop").action);
        assertEquals(Action.REMEMBER,CommandParser.parse("remember that filters are in truck").action);
        assertEquals(Action.RECALL,CommandParser.parse("recall filters").action);
    }
    @Test public void packageAndRolesAreRestricted() {
        assertTrue(Policy.canAccessPackage(Policy.TARGET_PACKAGE));
        assertFalse(Policy.canAccessPackage("com.android.settings"));
        assertFalse(Policy.canAccessPackage("com.android.chrome"));
        assertTrue(Policy.isRestricted("Management Reports"));
        assertFalse(Policy.screenTargetMatches("Administrator settings","admin"));
    }
    @Test public void credentialsAreNotAccepted() {
        assertTrue(Policy.isSensitive("Enter verification code"));
        assertTrue(Policy.isSensitive("Password reset"));
        assertFalse(Policy.validNote("my password is 1234"));
        assertFalse(Policy.validOrderTarget("payroll screen"));
        assertFalse(Policy.validOrderTarget("a"));
        assertTrue(Policy.validOrderTarget("unit 132"));
    }
}
